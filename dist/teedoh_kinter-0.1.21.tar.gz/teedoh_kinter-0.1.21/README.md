# TeedohKinter
A superset of TKinter with prebuilt components for straightforward frontends
